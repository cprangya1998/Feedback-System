import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, of } from "rxjs";

export class Employee {
  empId: string;
  empName: string;
  password: string;
}

@Injectable({
  providedIn: "root"
})
export class EmployeeService {
  private employeeUrl = "http://localhost:8080/api/employee";
  public employee: Employee;

  constructor(private http: HttpClient) { }

  ifExsist(body: Employee): Observable<Boolean> {
    return this.http.post<Boolean>(this.employeeUrl + "/exists", body);
  }

  loginValid(body: Employee): Observable<Boolean> {
    return this.http.post<Boolean>(this.employeeUrl + "/loginValidate", body);
  }

  add(body: Employee): Observable<Boolean> {
    return this.http.post<Boolean>(this.employeeUrl + "/addEmployee", body);
  }
}
