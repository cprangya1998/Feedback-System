import { Component, OnInit } from "@angular/core";
import { EmployeeService, Employee } from "../employee.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  constructor(private employeeService: EmployeeService, employee: Employee) { }
  allowed: any;
  ngOnInit(

  ) { }

  loginAllowed(employee): boolean {
    console.log(employee)
    this.employeeService
      .loginValid(employee)
      .subscribe(o => (this.allowed = o));
    return this.allowed;
  }
}
