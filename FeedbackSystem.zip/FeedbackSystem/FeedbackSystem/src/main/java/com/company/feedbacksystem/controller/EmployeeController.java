package com.company.feedbacksystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.company.feedbacksystem.entity.Employee;
import com.company.feedbacksystem.repository.EmployeeRepository;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;

	// get all the employees
	@GetMapping("/employees")
	public List<Employee> getEmployees() {
		return (List<Employee>) employeeRepository.findAll();
	}

	// add a new employee
	@ResponseStatus(code = HttpStatus.CREATED)
	@PostMapping("/employee")
	public void addEmployee(@RequestBody Employee employee) {
		employeeRepository.save(employee);
	}

	// get a employee with id
	@ResponseStatus(code = HttpStatus.OK)
	@PostMapping("/employee/{id}")
	public void getEmployee(@RequestBody Employee employee) {
		employeeRepository.save(employee);
	}

	// check if the login credentials are correct
	@PostMapping("/loginValidate")
	@ResponseStatus(code = HttpStatus.OK)
	public boolean validateIdandPassword(@RequestBody Employee employee) {
		Optional<Employee> e = employeeRepository.findById(employee.getEmpId());
		if (!e.isPresent()) {
			return e.get().getPassword().equals(employee.getPassword());
		}
		return false;
	}

	// check if the employee record exists
	@PostMapping("/exists")
	@ResponseStatus(code = HttpStatus.OK)
	public boolean idExists(@RequestBody Employee employee) {
		return employeeRepository.findById(employee.getEmpId()).isPresent();

	}
}
