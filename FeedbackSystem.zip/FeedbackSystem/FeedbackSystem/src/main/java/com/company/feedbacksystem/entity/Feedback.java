package com.company.feedbacksystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "feedbackform")
public class Feedback {

	@Id
	@GeneratedValue
	@Column(name = "Id")
	private Integer id;

	@Column(name = "CourseName")
	private String courseName;

	@Column(name = "IsContentRelevant")
	private String isContentRelevant;

	@Column(name = "IsHandsOn")
	private String isIsHandsOn;

	@Column(name = "ProficiencyLev")
	private String proficiencyLev;

	@Column(name = "RatingContent")
	private String ratingContent;

	@Column(name = "RatingHandsOn")
	private String ratingHandsOn;

	@Column(name = "Comments")
	private String comments;

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getIsContentRelevant() {
		return isContentRelevant;
	}

	public void setIsContentRelevant(String isContentRelevant) {
		this.isContentRelevant = isContentRelevant;
	}

	public String getIsIsHandsOn() {
		return isIsHandsOn;
	}

	public void setIsIsHandsOn(String isIsHandsOn) {
		this.isIsHandsOn = isIsHandsOn;
	}

	public String getProficiencyLev() {
		return proficiencyLev;
	}

	public void setProficiencyLev(String proficiencyLev) {
		this.proficiencyLev = proficiencyLev;
	}

	public String getRatingContent() {
		return ratingContent;
	}

	public void setRatingContent(String ratingContent) {
		this.ratingContent = ratingContent;
	}

	public String getRatingHandsOn() {
		return ratingHandsOn;
	}

	public void setRatingHandsOn(String ratingHandsOn) {
		this.ratingHandsOn = ratingHandsOn;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Feedback(Integer id, String courseName, String isContentRelevant, String isIsHandsOn,
			String proficiencyLev, String ratingContent, String ratingHandsOn, String comments) {
		super();
		this.id = id;
		this.courseName = courseName;
		this.isContentRelevant = isContentRelevant;
		this.isIsHandsOn = isIsHandsOn;
		this.proficiencyLev = proficiencyLev;
		this.ratingContent = ratingContent;
		this.ratingHandsOn = ratingHandsOn;
		this.comments = comments;
	}

	public Feedback() {
		super();

	}

}
