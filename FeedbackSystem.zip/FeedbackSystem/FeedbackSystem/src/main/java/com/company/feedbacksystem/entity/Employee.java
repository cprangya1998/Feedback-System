package com.company.feedbacksystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "employeedetail")
public class Employee {
	
	@Id
	@NotNull
	@Column(name = "EmpId")
	private Integer empId;

	@Column(name = "EmpName")
	private String empName;

	@Column(name = "Password")
	
	private String password;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Employee(Integer empId, String empName, String password) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.password = password;
	}
	
	public Employee() {
		super();
		
	}

}


