package com.company.feedbacksystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.feedbacksystem.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}

