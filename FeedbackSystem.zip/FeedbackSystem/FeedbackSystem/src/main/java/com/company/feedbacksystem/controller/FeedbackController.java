package com.company.feedbacksystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.company.feedbacksystem.entity.Feedback;
import com.company.feedbacksystem.repository.FeedbackRepository;

import org.springframework.http.HttpStatus;

@RestController
public class FeedbackController {
	@Autowired
	private FeedbackRepository feedbackRepository;
	
	//submit 
@ResponseStatus()
    @PostMapping("/submitFeedback")
   Feedback submitfeedback(@RequestBody Feedback feedback) {
       return feedbackRepository.save(feedback);
   }
	
	
	//view
	@GetMapping("/feedbacks")
   List<Feedback> findAll() {
        return feedbackRepository.findAll();
    }
	
	
	
	//edit
	@ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/editfeedbacks/{id}")
Feedback resetfeedback(@RequestBody Feedback feedback) {
        return feedbackRepository.save(feedback);
    }
	
	//delete
	
	 @PostMapping("/deletefeedbacks/{id}")
	public void deleteFeedback(@PathVariable Integer id) {
		 feedbackRepository.deleteById(id);
	}
	 
	

	

}
